﻿using dOOPTaskb.Core;

MyClass myClass = new MyClass();

myClass.Index = "1241214441252";
myClass.Country = "Россия";
myClass.City = "Тула";
myClass.Street = "Ломоносова 15";
myClass.House = "15";
myClass.Appartament = "27";
Console.WriteLine("Индекс " +myClass.Index);
Console.WriteLine($"Страна " +myClass.Country);
Console.WriteLine($"Город " +myClass.City);
Console.WriteLine($"Улица " +myClass.Street);
Console.WriteLine($"Дом " +myClass.House);
Console.WriteLine($"Квартира " +myClass.Appartament);

Console.WriteLine();

Rectangle rectangle = new Rectangle(1.2, 2.1);

Console.WriteLine(rectangle.Area);
Console.WriteLine(rectangle.Perimeter);