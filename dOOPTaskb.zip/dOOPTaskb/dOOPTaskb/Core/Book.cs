﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dOOPTaskb.Core
{
    public class Book
    {
        private class _Title
        {
            public string title;
            public void Show()
            {

            }
            
        }
        private class _Author
        {
            public string author;
            public void Show()
            {

            }
        }
        private class _Content
        {
            public string content;
            public void Show()
            {

            }
        }
       
    }
}
