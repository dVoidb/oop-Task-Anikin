﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dOOPTaskb.Core
{
    public class MyClass
    {
        private string index;
        private string country;
        private string city;
        private string street;
        private string house;
        private string appartament;

        private string _index;
        public string Index
        {
            get => _index;
            set => _index = value;
        }
        private string _country;
        public string Country
        {
            get => _country;
            set => _country = value;
        }
        private string _city;
        public string City
        {
            get => _city;
            set => _city = value;
        }
        private string _street;
        public string Street
        {
            get => _street;
            set => _street = value;
        }
        private string _house;
        public string House
        {
            get => _house;
            set => _house = value;
        }
        private string _appartament;
        public string Appartament
        {
            get => _appartament;
            set => _appartament = value;
        }



    }
}
